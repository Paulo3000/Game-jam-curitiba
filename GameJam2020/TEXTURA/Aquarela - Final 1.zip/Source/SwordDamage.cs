﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwordDamage : MonoBehaviour
{
    public float damage = 10f;
    public float force = 600f;
    public bool shouldDamage = false;
}
